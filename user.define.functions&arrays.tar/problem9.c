#include <stdio.h>

long long int printSum(int r, int c, int array[r][c]);

int main()
{
    int rowsForArray, columnsForArray;
    scanf("%d%d", &rowsForArray, &columnsForArray);

    int Array1[rowsForArray][columnsForArray];
    for (int i = 0; i < rowsForArray; i++)
    {
        for (int j = 0; j < columnsForArray; j++)
        {
            scanf("%d", &Array1[i][j]);
        }
    }

    long long theSummition = printSum(rowsForArray, columnsForArray, Array1);
    
    printf("%lld\n", theSummition);
    return 0;
}

long long int printSum(int r, int c, int array[r][c])
{
    long long  sum = 0;

    for (int j = 0; j < c; j++) 
    {
        for (int i = 0; i < r; i++) 
        {
            sum = (sum * 10) + array[i][j];
        }
        sum = sum / 10;
    }

    return sum;
}