// write your function prototype(s) here




void readArray(int size, double array[]);
double dotProduct(int size, double array1[], double array2[]);
double magnitude(int size, double array[]);
double radiansToDegrees(double radians);


