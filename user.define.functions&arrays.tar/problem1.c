#include <stdio.h>

void max (int count , int Array1[] , int numSwaps);
void Swaps(int numofswaps);
int main()
{
    int count;
    int NoOfSwAApS = 0;
    
    
    scanf("%d" , &count);
    
    int Array1[count];
    
    for (int i=0 ; i<count ; i++)
    {
        scanf("%d", &Array1[i]);
        
    }
    
    
    max (count,Array1,NoOfSwAApS);
    
   
    

    
    for (int z = 0 ; z < count ; z++) 
    {
        printf("%d ", Array1[z]);
    }
    return 0;
}




void max (int count, int Array1[] , int numSwaps)
{
    int i = 0;
    while(i < count - 1)
    {
        int ThEmAxImUmIndex = i;
        for (int j = i + 1; j < count; j++)
        {
            if (Array1[j] > Array1[ThEmAxImUmIndex]) {
                ThEmAxImUmIndex = j;
            }
        }

        if (ThEmAxImUmIndex != i) 
        {
            // Swap elements if needed
            int temporary = Array1[i];
            Array1[i] = Array1[ThEmAxImUmIndex];
            Array1[ThEmAxImUmIndex] = temporary;
            
            numSwaps++;
        }
         i++;
    }
    
     Swaps(numSwaps);
}

void Swaps(int numofswaps)
{
    if (numofswaps==1) printf("1 swap\n");
    else printf("%d swaps\n" , numofswaps);
}
    
    
    

