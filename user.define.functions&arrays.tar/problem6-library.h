// write your function prototype(s) here

#ifndef PROBLEM6_LIBRARY_H
#define PROBLEM6_LIBRARY_H

void findFreq(int freqArray[], int size, int array[]);
void findIntersection(int size1, int array1[], int size2, int array2[]);

#endif // PROBLEM6_LIBRARY_H

