#include <stdio.h>


void printArray(int r , int c , int array[r][c]);
void fill(int n , int m , int r , int c  , int array[r][c] );
int main()
{
    int nums;
    int majors;
    int rows;
    int columns;
   
    scanf("%d%d",&nums, &majors);

    
int Array1[nums][majors];

    
    for (int i = 0; i < nums; i++)
    {
        for (int j = 0; j < majors; j++) 
        {
            scanf("%d", &Array1[i][j]);
        }
    }

    
    scanf("%d %d", &rows, &columns);

    int newArray1[rows][columns];

        int row = 0, col = 0;
    for (int i = 0; i < nums * majors; i++) 
    {
        newArray1[row][col] = Array1[i / majors][i % majors];  
        col+=1;
        if (col == columns)
        {
            col = 0;
            row+=1;
        }
    }

   fill(nums , majors , rows , columns ,newArray1 );
    printArray(rows,columns , newArray1);

    return 0;
}
void printArray(int r , int c , int array[r][c])
{
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            printf("%d ", array[i][j]);
        }
        printf("\n");
    }
}

void fill(int n , int m , int r , int c , int array[r][c] )
{
     int Array1Size = n * m;
    int newArray1Size = r * c;

   
    if (newArray1Size > Array1Size) 
    {
		int sub = newArray1Size - Array1Size;
		for (int i = 0; i <= sub ; i++)
		{
		    array[r - 1][c - i] = 1;
		}
		
	}
    
    
    
    
    
}


