#include <stdio.h>

void frequency(int frequencyArr[], int frstarr[], int noOfnums);

int main() {
    int noOfnums;
    
    scanf("%d", &noOfnums);

    int elements[noOfnums];

    for (int i = 0; i < noOfnums; ++i) {
        scanf("%d", &elements[i]);
    }

    int maxElement = 1300;
    int frequencyArray1[maxElement + 1];
    
    frequency(frequencyArray1,elements, noOfnums);

    int numsforCheCK;

    scanf("%d", &numsforCheCK);

    for (int i = 0; i < numsforCheCK; ++i) {
        int numtoCheCK;
        
        scanf("%d", &numtoCheCK);

        printf("%d\n", frequencyArray1[numtoCheCK]);
    }

    return 0;
}

void frequency(int frequencyArr[], int frstarr[], int noOfnums) {
 int i = 0;
int maxElement = 1300;
    while ( i <= maxElement)
    {
        
        frequencyArr[i] = 0;
         ++i;
    }

   
    for (int i = 0; i < noOfnums; ++i)
    {
        int index = frstarr[i];
	frequencyArr[index] += 1;
    }
}

