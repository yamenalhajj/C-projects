#include <stdio.h>

int sizeSingle(int arr[], int n);

int main() {
    int noOfshoes;
    scanf("%d", &noOfshoes);
    
    if (noOfshoes%2 == 0) return 0;

    int Array1[noOfshoes];

    for (int i = 0; i < noOfshoes; i++)
    {
        scanf("%d", &Array1[i]);
    }

    int elFardEh = sizeSingle(Array1,noOfshoes);

    printf("%d\n", elFardEh);

    return 0;
}

int sizeSingle(int arr[], int number)
        {
    for (int i = 0; i < number; i++) 
    {
        int count = 0;
        for (int j = 0; j < number; j++) 
        {
            if (arr[i] == arr[j]) count++;
                
            
        }
        if (count == 1)  return arr[i];
           
        
    }
   
    return -1;
    }
