// problem6-library.c

#include "problem6-library.h"
#include <stdio.h>

void findFreq(int freqArr[], int size, int arr[]) {

int i = 0;   
	while ( i < 1001)
     {
        freqArr[i] = 0;
	i++;
    }
    for (int i = 0; i < size; i++) {
        int index = arr[i];
	freqArr[index] += 1;
    }
}

void findIntersection(int size1, int arr1[], int size2, int arr2[]) {
    int freqArr1[1001] = {};
    int freqArr2[1001] = {};

    findFreq(freqArr1, size1, arr1);
    findFreq(freqArr2, size2, arr2);

    for (int i = 0; i <= 1000; i++) {
        if (freqArr1[i] > 0 && freqArr2[i] > 0) {
            printf("%d ", i);
        }
    }
    printf("\n");
}









