#include <stdio.h>
#include <math.h>
#define PI 3.14
void readArray(int size, double array[])
{
    for (int i =0 ; i < size ; i++)
    {
        scanf("%lf" , &array[i]);
    }

}


double dotProduct(int size, double array1[], double array2[]) {
    double result = 0.0;
    int i = 0;
    while (i < size) 
    {
        result = result + (array1[i] * array2[i]);
        i++;
    }
    return result;
}

double magnitude(int size, double array[])
{
    double result1 = 0.0;
    double result2 = 0.0;
    for (int i = 0; i < size ; i++)
    {
         result1 = result1 + pow (array[i] , 2);
    }
    
    result2 = sqrt(result1);
    
    return result2;
}


double radiansToDegrees(double theta)
{
    double result = 0.0;

    result = theta * 57.2958;

   
   

    return result;
}
