// implement the functions inside problem8-library.h here
// DO NOT write a main function


#include <stdio.h>


#include "problem8-library.h"

double findTerm(double x, double xj, double xk) {
    double divisor = (x - xk) / (xj - xk);
    return divisor;
}

double findAllPointTerms(double x, int numPoints, double pointsX[], double pointsY[], int j) {
    double product = 1.0;

    for (int k = 0; k < numPoints; ++k) {
        if (k != j) {
            product *= findTerm(x, pointsX[j], pointsX[k]);
        }
    }
    double multiply =product * pointsY[j];
    return multiply;
}

double findY(double x, int numPoints, double pointsX[], double pointsY[]) {
    double summition = 0.0;

    for (int j = 0; j < numPoints; ++j) 
    {
        summition =summition + findAllPointTerms(x, numPoints, pointsX, pointsY, j);
    }

    return summition;
}
