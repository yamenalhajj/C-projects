// Fix the issues in the replace function

int replace(int arr[], int size, int start, int toFind, int replaceWith) {
    for (int i = start; i < size; ++i) {
        if (arr[i] == toFind) {
            arr[i] = replaceWith;
            start = i ;
            return i;
        }
    }
    return -1;
}

/*
   The issues is .
  1- It used the variable "i" to compare with the value to find, instead of using the array element at index "i."
    "if (i == toFind)" and we solve it by 
    
    comparing the array[i] with the to find insted of comparing the i with to find
    
2-The function always returned -1 if the value to find was not found, even if it was found before and replaced.
   and we solve it by
   1-deleting the else statement
   2-putting the "return -1" outside the loop 
   3-putting the return "start inside" the loop insted of the "return -1"
*/

