#include <stdio.h>
#include <math.h>
#include "problem8-library.h"

int main()
{
    double ThEtA0;
    double ThEtA0InRad0;
    double SiNXtrig=0.0,SeMesTeR=0.0;
    long long NoOfTeRmSNo;
    int Y=0;

    scanf("%lf %lld",&ThEtA0,&NoOfTeRmSNo);

    ThEtA0InRad0=ThEtA0*3.14/180.0;

    for (;Y<NoOfTeRmSNo;++Y) 
    
    {
        SeMesTeR=pow(-1,Y)*pow(ThEtA0InRad0,2*Y+ 1)/ factorial ( 2 * Y +  1 );
        SiNXtrig= SiNXtrig+SeMesTeR;
    }

    printf("%.12lf\n", SiNXtrig);

    return 0;
}
