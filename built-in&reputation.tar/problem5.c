#include <stdio.h>

int main() 
{
    int NoOfRoUnDs9095;
    int LeEEEnaWiNs9094=0;
    int Ni00gaWins9093=0;
    int AtlatecoMAdRiD_RoUnDDDDs9092=0;
    int NoOfChAlLeNgS9091;
   
    
        scanf("%i",&NoOfRoUnDs9095);
        
        for (int raula=0;raula<NoOfRoUnDs9095;raula++)
        {
        scanf("%i", &NoOfChAlLeNgS9091);
        
     int LeEnACAaLleNgEs=0;
     int SaMMMARCHalLeNgEs=0;
     int JaWlA9090=0;
      while (JaWlA9090<NoOfChAlLeNgS9091)
      {
          
         char ThEWiNnER9090;
         scanf(" %c",&ThEWiNnER9090);
         
         if (ThEWiNnER9090=='L'||ThEWiNnER9090=='l') LeEnACAaLleNgEs++;
         
         else if (ThEWiNnER9090=='S'||ThEWiNnER9090=='s') SaMMMARCHalLeNgEs++;
         
         if (LeEnACAaLleNgEs>NoOfChAlLeNgS9091/2||SaMMMARCHalLeNgEs>NoOfChAlLeNgS9091/2)
            {
                break;
            }
         
         JaWlA9090++;
      }
      

   
        if (LeEnACAaLleNgEs>NoOfChAlLeNgS9091/2)
        
        {
            LeEEEnaWiNs9094++;
            printf("Leena\n");
        } 
        
        else if (SaMMMARCHalLeNgEs>NoOfChAlLeNgS9091/2)
        
        {
            Ni00gaWins9093++;
            printf("Samar\n");
        }
        
        else 
        
        {
            AtlatecoMAdRiD_RoUnDDDDs9092++;
            printf("Tie\n");
        }
    }

    if (LeEEEnaWiNs9094>Ni00gaWins9093)  printf("Leena won the contest with %d round(s)\n", LeEEEnaWiNs9094);
    
       
     else if (Ni00gaWins9093 > LeEEEnaWiNs9094) 
     {
        printf("Samar won the contest with %d round(s)\n", Ni00gaWins9093);
     } 
    else printf("It is a tie with %d round(s) each\n", LeEEEnaWiNs9094);
        
    

    return 0;
}
        
        
        
        