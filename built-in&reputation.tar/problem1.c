
#include <stdio.h>
#include <math.h>

int main()
{
    int NuMbEr_SIU98;
    int EsSiNtIaL97_NuM;
    int NoOfDiGiTs96;
    int SuMmiTtIoN95=0;
    int tararararara94;
    int dIGGiTt93;
    
    
    scanf("%d",&NuMbEr_SIU98);
    
    EsSiNtIaL97_NuM=NuMbEr_SIU98;
    
    
    NoOfDiGiTs96=0;
    tararararara94=NuMbEr_SIU98;
    while (tararararara94!= 0)
    {
        tararararara94=tararararara94/10;
        NoOfDiGiTs96++;
    }
    
    
    tararararara94=EsSiNtIaL97_NuM;
    
    while (tararararara94!=0)
    {
        dIGGiTt93=tararararara94%10;
        SuMmiTtIoN95=SuMmiTtIoN95+pow(dIGGiTt93,NoOfDiGiTs96);
        tararararara94=tararararara94/10;
    }
    if (SuMmiTtIoN95==EsSiNtIaL97_NuM) printf("Ronaldo Number");
    else if (SuMmiTtIoN95==(EsSiNtIaL97_NuM)-7) 
    {
        printf("Ronaldo Number");
    }
    else if(SuMmiTtIoN95==(EsSiNtIaL97_NuM)+7) printf("Ronaldo Number");
    else if (SuMmiTtIoN95==(EsSiNtIaL97_NuM)*7) 
    {
        printf("Ronaldo Number");
        
    }
    else if(EsSiNtIaL97_NuM!=0&&SuMmiTtIoN95==EsSiNtIaL97_NuM/7) printf("Ronaldo Number");
    
    else 
    {
    printf("Not a Ronaldo Number");
    }
    

    return 0;
}
