#include <stdio.h>

int main() {
    int secret;
    char letter;
    scanf("%d", &secret);
    scanf(" %c", &letter);

    while (letter != '\n') {
        char newLetter = letter;

        if ((letter>='A'&&letter<='Z')||(letter>='a'&&letter<='z')) {
         if (letter>='A'&& letter<='Z') {
        newLetter='A'+(letter-'A'+secret)%26;
         if (newLetter>'Z') {
            newLetter=newLetter- 26;
           }
            } else if(letter>='a'&&letter<='z') {
         newLetter='a'+(letter-'a'+secret) % 26;
         if (newLetter>'z') {
        newLetter=newLetter- 26;
         }
            }
        }

        printf("%c", newLetter);
        scanf("%c", &letter);
    }

    return 0;
}

/*
    Write your explanation of what the issues were inside this comment after this line:


we putted two if statmentes sentences inside the loop to check if the letter is alphabetic and check if it is a lowercase or uppercase
we calculated the new encrypted letter based on divided by 26 algoritim newLetter =( 'A' + (letter - 'A' + secret) % 26;)
we putted we putted printf&scanf inside the loop printf(("%c", newLetter); scanf("%c", &letter); )
    
*/