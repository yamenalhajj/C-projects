#include <stdio.h>
#include "problem6-library.h"
int main()
{
    int ThE_HeIgHt90;
    
    scanf("%d",&ThE_HeIgHt90);
    
    for (int I2=0;I2<ThE_HeIgHt90/2;++I2)
    {
        if (I2%2==0) drawRow(I2,ThE_HeIgHt90-(2*I2),'x');
        
            
        
        else
        {
            drawRow(I2,ThE_HeIgHt90-(2*I2),'-');
        }
    }

    if (ThE_HeIgHt90%2!=0) drawRow(ThE_HeIgHt90/2,1,'H');
    
        
    

    for (int I3=(ThE_HeIgHt90/2)-1;I3>=0;--I3)
    {
        if (I3%2==0)
        {
            drawRow(I3,ThE_HeIgHt90-(2*I3),'x');
        }
        else drawRow(I3,ThE_HeIgHt90-(2*I3),'-');
        
    }

    return 0;
}