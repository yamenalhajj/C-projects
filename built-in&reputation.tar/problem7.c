#include <stdio.h>
#include "problem7-library.h"

int main() {
    long long NumBeR_1011;
    long long genolo101 = 0;
    long long leomessi090 = 1;
    long long THE_NuMbErOFtHeNumBeR;

    scanf("%lld",&THE_NuMbErOFtHeNumBeR);

    for (int ii9i=0;ii9i<THE_NuMbErOFtHeNumBeR;ii9i++) 
	{
        scanf("%lld",&NumBeR_1011);


        genolo101 = greatestCommonDivisor(genolo101,NumBeR_1011);
        leomessi090 = (leomessi090*NumBeR_1011) / greatestCommonDivisor(leomessi090,NumBeR_1011);
        }

    printf("GCD: %lld\n",genolo101);
    printf("LCM: %lld\n",leomessi090);

    return 0;
}