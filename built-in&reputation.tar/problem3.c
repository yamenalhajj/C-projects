#include <stdio.h>

int main() {
    int NUmBeR_1002;
    int EAFC2024;
    int SEC2NdnUmBeRR_1;
    
    int inI=0;

    scanf("%d",&NUmBeR_1002);
    scanf("%d",&EAFC2024);
    
    int SuMMution=0,PrEvNo2910 = 0;
    while (inI<NUmBeR_1002) {
        
        scanf("%d", &SEC2NdnUmBeRR_1);

        if ((SEC2NdnUmBeRR_1 % EAFC2024 != 0) && (PrEvNo2910 % EAFC2024 != 0 || PrEvNo2910 == 0)) SuMMution=SuMMution+SEC2NdnUmBeRR_1;
            
        

        PrEvNo2910 = SEC2NdnUmBeRR_1;
        
        inI++;
    }
    

    printf("%d\n",SuMMution);

    return 0;
}