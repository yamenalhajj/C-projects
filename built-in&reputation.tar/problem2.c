#include <stdio.h>
#include <math.h>


int main()
{
    int NoOfClients9098;
    char GenDeR929;
    double WeIgHt989;
    double HeIgHt14;
    int AgEE98;
    double BmR0909;
    double CaLoRiEInTaKe900;
    double BMII90;

    
    scanf("%d",&NoOfClients9098);

    for (int iii89i=0;iii89i<NoOfClients9098;iii89i++) 
    {
        
         scanf("%lf",&WeIgHt989);

        scanf("%lf",&HeIgHt14);
        
        scanf("%d",&AgEE98);
         
        scanf(" %c",&GenDeR929);
        
        
        
        if (WeIgHt989>0&&HeIgHt14>0&&AgEE98>0&&(GenDeR929=='M'||GenDeR929=='F'))
        {
            BMII90=(WeIgHt989)/pow(HeIgHt14/100,2);
            if(GenDeR929=='M'||GenDeR929=='m')
            
            BmR0909=88.362+(13.397*WeIgHt989)+(4.799*HeIgHt14)-(5.677*AgEE98);
            
            else if (GenDeR929=='F'||GenDeR929=='f')
            
            BmR0909=447.593+(9.247*WeIgHt989)+(3.098*HeIgHt14)-(4.330*AgEE98);
            
            
            
            
        
        if (BMII90<18.5) printf("%0.2lf",(BmR0909*1.5));
        else if (BMII90>=18.5&&BMII90<=24.9) 
        {
            printf("%0.2lf",(BmR0909*1.3));
        }
        else if(BMII90>24.9&&BMII90<=29.9) printf("%0.2lf",BmR0909);
        
        else
        {
            printf("%0.2lf",(BmR0909*0.8));
            
        }
        }
        
    else printf("Invalid input");
    printf("\n");

    } 
        
    
    

    return 0;
}